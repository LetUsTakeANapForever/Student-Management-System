-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2024 at 08:43 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `registered_subjects`
--

CREATE TABLE `registered_subjects` (
  `subject_id` varchar(8) DEFAULT NULL,
  `std_id` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `software_construction`
--

CREATE TABLE `software_construction` (
  `std_id` varchar(15) DEFAULT NULL,
  `std_firstname` varchar(30) DEFAULT NULL,
  `std_lastname` varchar(30) DEFAULT NULL,
  `grade` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `software_construction`
--

INSERT INTO `software_construction` (`std_id`, `std_firstname`, `std_lastname`, `grade`) VALUES
('b662160test', 'testFirstnme', 'lastnameTest', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `std_id` varchar(15) DEFAULT NULL,
  `std_password` varchar(8) DEFAULT NULL,
  `std_firstname` varchar(30) DEFAULT NULL,
  `std_lastname` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`std_id`, `std_password`, `std_firstname`, `std_lastname`) VALUES
('b6621601111', 'abcdefg', 'Koraye', 'KorGai'),
('b6621602222', 'hijklmn', 'KorKai', 'YooNaiLaow'),
('b6621603333', 'opqrstu', 'KorKon', 'KuengKang'),
('b6621604444', '1234567', 'Korrakang', 'Kangfah'),
('b6621605555', '7654321', 'Ngoorngoo', 'YooNaipah');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `t_id` varchar(15) DEFAULT NULL,
  `t_password` varchar(8) DEFAULT NULL,
  `t_firstname` varchar(30) DEFAULT NULL,
  `t_lastname` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`t_id`, `t_password`, `t_firstname`, `t_lastname`) VALUES
('t1234', 'imcool1', 'Ant', 'Antmod'),
('t4321', 'icanfly', 'Bird', 'Birdnok'),
('t5555', 'meow123', 'Cat', 'Catmaw'),
('t7788', 'boxbox8', 'Dog', 'Dogsunuk'),
('t3456', 'idkjk4', 'Eye', 'Eyeeyaieyai');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
