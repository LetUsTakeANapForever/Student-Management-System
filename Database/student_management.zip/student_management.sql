-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 26, 2024 at 11:11 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `all_subjects`
--

CREATE TABLE `all_subjects` (
  `subject_id` varchar(15) NOT NULL,
  `subject_name` varchar(30) DEFAULT NULL,
  `teacher_id` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `all_subjects`
--

INSERT INTO `all_subjects` (`subject_id`, `subject_name`, `teacher_id`) VALUES
('01355103', 'English', 't7788'),
('01417111', 'Calculus I', 't5555'),
('01418231', 'Data Structures and Algorithms', 't3456'),
('01418233', 'Computer Architecture', 't4321'),
('01419211', 'Software Construction', 't1234');

-- --------------------------------------------------------

--
-- Table structure for table `calculus_i`
--

CREATE TABLE `calculus_i` (
  `std_id` varchar(15) DEFAULT NULL,
  `grade` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `calculus_i`
--

INSERT INTO `calculus_i` (`std_id`, `grade`) VALUES
('b6621601111', NULL),
('b6621602222', NULL),
('b6621603333', NULL),
('b6621604444', NULL),
('b6621605555', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `computer_architecture`
--

CREATE TABLE `computer_architecture` (
  `std_id` varchar(15) DEFAULT NULL,
  `grade` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `computer_architecture`
--

INSERT INTO `computer_architecture` (`std_id`, `grade`) VALUES
('b6621601111', NULL),
('b6621602222', NULL),
('b6621603333', NULL),
('b6621604444', NULL),
('b6621605555', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `data_structures_and_algorithms`
--

CREATE TABLE `data_structures_and_algorithms` (
  `std_id` varchar(15) DEFAULT NULL,
  `grade` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `data_structures_and_algorithms`
--

INSERT INTO `data_structures_and_algorithms` (`std_id`, `grade`) VALUES
('b6621601111', NULL),
('b6621602222', NULL),
('b6621603333', NULL),
('b6621604444', NULL),
('b6621605555', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `english`
--

CREATE TABLE `english` (
  `std_id` varchar(15) DEFAULT NULL,
  `grade` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `english`
--

INSERT INTO `english` (`std_id`, `grade`) VALUES
('b6621601111', NULL),
('b6621602222', NULL),
('b6621603333', NULL),
('b6621604444', NULL),
('b6621605555', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `software_construction`
--

CREATE TABLE `software_construction` (
  `std_id` varchar(15) DEFAULT NULL,
  `grade` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `software_construction`
--

INSERT INTO `software_construction` (`std_id`, `grade`) VALUES
('b6621601111', NULL),
('b6621602222', NULL),
('b6621603333', NULL),
('b6621604444', NULL),
('b6621605555', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `std_id` varchar(15) DEFAULT NULL,
  `std_password` varchar(8) DEFAULT NULL,
  `std_firstname` varchar(30) DEFAULT NULL,
  `std_lastname` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`std_id`, `std_password`, `std_firstname`, `std_lastname`) VALUES
('b6621601111', 'abcdefg', 'Koraye', 'KorGai'),
('b6621602222', 'hijklmn', 'KorKai', 'YooNaiLaow'),
('b6621603333', 'opqrstu', 'KorKon', 'KuengKang'),
('b6621604444', '1234567', 'Korrakang', 'Kangfah'),
('b6621605555', '7654321', 'Ngoorngoo', 'YooNaipah');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `teacher_id` varchar(15) NOT NULL,
  `teacher_password` varchar(8) DEFAULT NULL,
  `teacher_firstname` varchar(30) DEFAULT NULL,
  `teacher_lastname` varchar(30) DEFAULT NULL,
  `subject_id` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teacher_id`, `teacher_password`, `teacher_firstname`, `teacher_lastname`, `subject_id`) VALUES
('t1234', 'imcool1', 'Ant', 'Antmod', NULL),
('t3456', 'idkjk4', 'Eye', 'Eyeeyaieyai', NULL),
('t4321', 'icanfly', 'Bird', 'Birdnok', NULL),
('t5555', 'meow123', 'Cat', 'Catmaw', NULL),
('t7788', 'boxbox8', 'Dog', 'Dogsunuk', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `all_subjects`
--
ALTER TABLE `all_subjects`
  ADD PRIMARY KEY (`subject_id`),
  ADD KEY `FK_t_id` (`teacher_id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacher_id`),
  ADD KEY `FK_subject_id` (`subject_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `all_subjects`
--
ALTER TABLE `all_subjects`
  ADD CONSTRAINT `FK_t_id` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`);

--
-- Constraints for table `teachers`
--
ALTER TABLE `teachers`
  ADD CONSTRAINT `FK_subject_id` FOREIGN KEY (`subject_id`) REFERENCES `all_subjects` (`subject_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
