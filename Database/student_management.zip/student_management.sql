-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 27, 2024 at 07:25 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `all_subjects`
--

CREATE TABLE `all_subjects` (
  `subject_id` varchar(15) NOT NULL,
  `subject_name` varchar(30) DEFAULT NULL,
  `teacher_id` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `all_subjects`
--

INSERT INTO `all_subjects` (`subject_id`, `subject_name`, `teacher_id`) VALUES
('01355103', 'English', 't7788'),
('01417111', 'Calculus I', 't5555'),
('01418231', 'Data Structures and Algorithms', 't3456'),
('01418233', 'Computer Architecture', 't4321'),
('01419211', 'Software Construction', 't1234');

-- --------------------------------------------------------

--
-- Table structure for table `homework`
--

CREATE TABLE `homework` (
  `homework_id` int(11) NOT NULL,
  `assigned_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `subject_id` varchar(15) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `assigned_to_std` varchar(15) DEFAULT NULL,
  `assigned_by_teacher` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `homework`
--

INSERT INTO `homework` (`homework_id`, `assigned_date`, `due_date`, `subject_id`, `description`, `assigned_to_std`, `assigned_by_teacher`) VALUES
(1, '2024-09-28', '2024-09-27', '01419211', 'Solve problem 2', 'b6621601111', 't1234'),
(2, '2024-09-28', '2024-09-28', '01419211', 'Do lab 2', 'b6621602222', 't1234');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `std_id` varchar(15) DEFAULT NULL,
  `subject_id` varchar(15) DEFAULT NULL,
  `grade` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`std_id`, `subject_id`, `grade`) VALUES
('b6621601111', '01355103', NULL),
('b6621601111', '01417111', NULL),
('b6621601111', '01418231', NULL),
('b6621601111', '01418233', NULL),
('b6621601111', '01419211', NULL),
('b6621602222', '01355103', NULL),
('b6621602222', '01417111', NULL),
('b6621602222', '01418231', NULL),
('b6621602222', '01418233', NULL),
('b6621602222', '01419211', NULL),
('b6621603333', '01355103', NULL),
('b6621603333', '01417111', NULL),
('b6621603333', '01418231', NULL),
('b6621603333', '01418233', NULL),
('b6621603333', '01419211', NULL),
('b6621604444', '01355103', NULL),
('b6621604444', '01417111', NULL),
('b6621604444', '01418231', NULL),
('b6621604444', '01418233', NULL),
('b6621604444', '01419211', NULL),
('b6621605555', '01355103', NULL),
('b6621605555', '01417111', NULL),
('b6621605555', '01418231', NULL),
('b6621605555', '01418233', NULL),
('b6621605555', '01419211', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `std_id` varchar(15) NOT NULL,
  `std_password` varchar(8) DEFAULT NULL,
  `std_firstname` varchar(30) DEFAULT NULL,
  `std_lastname` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`std_id`, `std_password`, `std_firstname`, `std_lastname`) VALUES
('b6621601111', 'abcdefg', 'Koraye', 'KorGai'),
('b6621602222', 'hijklmn', 'KorKai', 'YooNaiLaow'),
('b6621603333', 'opqrstu', 'KorKon', 'KuengKang'),
('b6621604444', '1234567', 'Korrakang', 'Kangfah'),
('b6621605555', '7654321', 'Ngoorngoo', 'YooNaipah');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `teacher_id` varchar(15) NOT NULL,
  `teacher_password` varchar(8) DEFAULT NULL,
  `teacher_firstname` varchar(30) DEFAULT NULL,
  `teacher_lastname` varchar(30) DEFAULT NULL,
  `subject_id` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teacher_id`, `teacher_password`, `teacher_firstname`, `teacher_lastname`, `subject_id`) VALUES
('t1234', 'imcool1', 'Ant', 'Antmod', '01419211'),
('t3456', 'idkjk4', 'Eye', 'Eyeeyaieyai', '01418231'),
('t4321', 'icanfly', 'Bird', 'Birdnok', '01418233'),
('t5555', 'meow123', 'Cat', 'Catmaw', '01417111'),
('t7788', 'boxbox8', 'Dog', 'Dogsunuk', '01355103');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `all_subjects`
--
ALTER TABLE `all_subjects`
  ADD PRIMARY KEY (`subject_id`),
  ADD KEY `FK_t_id` (`teacher_id`);

--
-- Indexes for table `homework`
--
ALTER TABLE `homework`
  ADD PRIMARY KEY (`homework_id`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `assigned_to_std` (`assigned_to_std`),
  ADD KEY `assigned_by_teacher` (`assigned_by_teacher`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD KEY `std_id` (`std_id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`std_id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacher_id`),
  ADD KEY `FK_subject_id` (`subject_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `homework`
--
ALTER TABLE `homework`
  MODIFY `homework_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `all_subjects`
--
ALTER TABLE `all_subjects`
  ADD CONSTRAINT `FK_t_id` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`);

--
-- Constraints for table `homework`
--
ALTER TABLE `homework`
  ADD CONSTRAINT `homework_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `all_subjects` (`subject_id`),
  ADD CONSTRAINT `homework_ibfk_2` FOREIGN KEY (`assigned_to_std`) REFERENCES `students` (`std_id`),
  ADD CONSTRAINT `homework_ibfk_3` FOREIGN KEY (`assigned_by_teacher`) REFERENCES `teachers` (`teacher_id`);

--
-- Constraints for table `registration`
--
ALTER TABLE `registration`
  ADD CONSTRAINT `registration_ibfk_1` FOREIGN KEY (`std_id`) REFERENCES `students` (`std_id`),
  ADD CONSTRAINT `registration_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `all_subjects` (`subject_id`);

--
-- Constraints for table `teachers`
--
ALTER TABLE `teachers`
  ADD CONSTRAINT `FK_subject_id` FOREIGN KEY (`subject_id`) REFERENCES `all_subjects` (`subject_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
